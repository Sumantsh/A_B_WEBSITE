@include('header')

    <section id="contactsection" >


      <h2 style="text-align: center; margin: 10% 0px 0% 0px; color: #333333; font-family: open, sans-serif; font-weight: 600; font-size: 20px;" >Got any Questions?</h2>

      <div class="contact" id="contactpage"  >
        <a href="" style="font-size: 10px; color: #333333; font-family: open, sans-serif; font-weight: 400;"><h2 style="border-bottom: 1px solid #333333; padding: 15px;" ><span style="margin: 0px 2%;"><i class="fa-solid fa-phone-volume"></i></span>+1888 696 2118</h2></a>

        <a href="" style="font-size: 10px; color: #333333; font-family: open, sans-serif; font-weight: 400;"><h2 style=" padding: 15px;" ><span style="margin: 0px 2%;"></span>contact@edlifecare.com</h2></a>
        
        <div class="socialmedia" id="socialmedia">
          <a href="" class="facebook"><i class="fa-brands fa-facebook"></i></a>
          <a href="" class="twitter"><i class="fa-brands fa-twitter"></i></a>
          <a href="" class="insta"><i class="fa-brands fa-instagram"></i></a>
          <a href="" class="whatsapp"><i class="fa-brands fa-whatsapp"></i></a>
          <a href="" class="telegram"><i class="fa-brands fa-telegram"></i></a>
        </div>

        
      <h2 id="Contact_Us_Now"  >Contact Us Now</h2>

      </div>


    </section>

@include('footer')