$(document).ready( function () {



    var showvalue1 =     parseInt($("#showvalue").text()); 
    
 
    i = 1;

   
 
    $("#plus").on('click',function(){

       if (showv)

     

    });

    


    
   
 
        $("#minus").on('click',function(){
    
           
    
          
        });
    
        
    






});