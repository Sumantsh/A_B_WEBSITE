<div>
<?php if($isOpen): ?>
<div id="cartwindow">
    <div class="innerwindow">
        <div class="topwrapper">
            <div class="icon" style="position: relative;"><span><img src="<?php echo e(asset ('img/icon/bag.svg')); ?>" width="30px"
                        style="position: relative;" alt=""></span></div>

            <div class="heading" style="padding: 0px 10px;">
                <p>Your Cart</p>
            </div>

            <div class="cross" style="cursor: pointer;" wire:click="toggleCart">
                <i class="fa-solid fa-xmark"></i>
            </div>
        </div>

        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div id="productvalues" wire:key="<?php echo e($product['UID']); ?>">
                <div class="productimg">
                    <img src="<?php echo e($product['prd_image']); ?>"  alt="">
                </div>

                <div class="numberofitems">
                    <p style="font-family: 'Poppins', sans-serif; "><span><?php echo e($product['prd_name']); ?></span> - <span id="mumberofpills"></span><?php echo e($product['pills']); ?><span> pills,</span><br>
                    <span id="pillsmg"><?php echo e($product['mg']); ?></span><span> mg</span> </p>
                    <p><span id="itemsvalues"><?php echo e($product['qty']); ?></span> <span>X</span> <span>$ <span id="productprice"><?php echo e($product['price']); ?></span>
                    <span>=</span> <span>$</span> <span id="totalprice"><?php echo e($product['qty'] * $product['price']); ?></span> </span></p>
                </div>

                <div class="delete" wire:click="remove('<?php echo e($product['UID']); ?>')">
                    <i class="fa-regular fa-trash-can"></i>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div id="checkout" style="background: ">
            <?php 
                    $total = 0;
                    foreach ($products as $product) {
                        $total += $product['price'] * $product['qty'];
                    }
            ?>

            <?php if(count($products)> 0): ?>
                <div class="subtotal"> Subtotal: <span style="margin-left: 0%; color: #57BF6D;">$</span> <span style="margin-left: -5px; color: #57BF6D;">
                    <?php echo e($total); ?>    
                </span> 
                </div>
            <?php endif; ?>
        
        <div class="buttonwrapper">
            <?php if(count($products)): ?>
                <div class="checkout" wire:click="emptyCart()">
                    <a href="">CHECKOUT</a>
                </div>
            <?php endif; ?>
            <div class="viewcart">
                <a href="">VIEW CART</a>
            </div>

            <div class="continushoping">
                <a href="">CONTINUE SHOPPING</a>
            </div>
        </div>
        </div>
    </div>
</div>
<?php endif; ?>

<div id="carticon2" wire:click="toggleCart">
    <img src="<?php echo e(asset ('img/icon/bagicon.svg')); ?>" class="bagicon" alt="">
    <div
        style="position: absolute; background: black; border-radius: 50%; width:40px;height:40px; color: white; text-align: center; top: -12px; left: -7px; box-shadow: 2px 2px 4px rgba(0, 0, 0,.4) ; display:flex; justify-content:center; align-items:center; ">
        <span><?php echo e(count($products)); ?></span></div>
</div>
</div><?php /**PATH C:\Users\MSI\Documents\github\laravel\my_first_app\A_WEBSITE\resources\views/livewire/cart.blade.php ENDPATH**/ ?>