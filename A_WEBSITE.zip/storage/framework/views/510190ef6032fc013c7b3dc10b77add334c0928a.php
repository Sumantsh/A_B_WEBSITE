    <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section id="section">

    <div class="swiper-container">

        <div class="container cardslider swiper" id="cardslider">

            <div class="swiper-wrapper">

                <div class="slider swiper-slide slider1 ">
                    <img src="<?php echo e(asset('img/slider/new/1.jpg')); ?>" width="100%" alt="">
                </div>

                <div class="slider swiper-slide slider2 ">
                    <img src="<?php echo e(asset('img/slider/new/2.jpg')); ?>" width="100%" alt="">
                </div>

                <div class="slider swiper-slide slider3 ">
                    <img src="<?php echo e(asset('/img/slider/new/3.jpg')); ?>" width="100%" alt="">
                </div>

            </div>



            <!-- If we need navigation buttons -->
            <div class="swiper-button-prev"></div>
            <div class="swiper-button-next"></div>
            <div class="swiper-pagination" style="bottom: 10px; color: black;"></div>

        </div>
    </div>



    <div id="afterslider">
        <div id="productwrapper">
            <div id="leftsideoffer">
                <div>
                    <div style="display: flex; flex-direction: column; align-items: center;">
                        <img src="<?php echo e(asset('/img/Screenshot_2022-10-02_at_11.52.57_PM-removebg-preview.png')); ?>"
                            width="80%" alt="">
                        <div
                            style="width: 50%; height: 1px; margin: 2% 0px; background-color: rgb(0, 0, 0); text-align: center;">
                        </div>

                        <div class="TESTIMONIALS">

                            <h2>TESTIMONIALS</h2>
                            <div class="testomonials_wrapper">
                                <div class="review">
                                    <li>
                                        Highest quality at a lowest price I would consider sane. You know how to win clientsRa
                                    </li>
                                </div>
                                <div class="client">
                                    <p>Richard 28year</p>
                                </div>
                                <div class="review">
                                    <li>
                                        Highest quality at a lowest price I would consider sane. You know how to win clientsRa
                                    </li>
                                </div>
                                <div class="client">
                                    <p>Richard 28year</p>
                                </div>
                                <div class="review">
                                    <li>
                                        Highest quality at a lowest price I would consider sane. You know how to win clientsRa
                                    </li>
                                </div>
                                <div class="client">
                                    <p>Richard 28year</p>
                                </div>
                                <div class="review">
                                    <li>
                                        Highest quality at a lowest price I would consider sane. You know how to win clientsRa
                                    </li>
                                </div>
                                <div class="client">
                                    <p>Richard 28year</p>
                                </div>
                                <div class="review">
                                    <li>
                                        Highest quality at a lowest price I would consider sane. You know how to win clientsRa
                                    </li>
                                </div>
                                <div class="client">
                                    <p>Richard 28year</p>
                                </div>
                                <div class="review">
                                    <li>
                                        Highest quality at a lowest price I would consider sane. You know how to win clientsRa
                                    </li>
                                </div>
                                <div class="client">
                                    <p>Richard 28year</p>
                                </div>
                                <div class="review">
                                    <li>
                                        Highest quality at a lowest price I would consider sane. You know how to win clientsRa
                                    </li>
                                </div>
                                <div class="client">
                                    <p>Richard 28year</p>
                                </div>
                                <div class="review">
                                    <li>
                                        Highest quality at a lowest price I would consider sane. You know how to win clientsRa
                                    </li>
                                </div>
                                <div class="client">
                                    <p>Richard 28year</p>
                                </div>
                                <div class="review">
                                    <li>
                                        Highest quality at a lowest price I would consider sane. You know how to win clientsRa
                                    </li>
                                </div>
                                <div class="client">
                                    <p>Richard 28year</p>
                                </div>
                                <div class="review">
                                    <li>
                                        Highest quality at a lowest price I would consider sane. You know how to win clientsRa
                                    </li>
                                </div>
                                <div class="client">
                                    <p>Richard 28year</p>
                                </div>
                            </div>

                        </div>

                        <div
                        style="width: 50%; height: 1px; margin: 4% 0px; background-color: rgb(0, 0, 0); text-align: center;">
                    </div>

                        <div class="conatctus">
                            <a class="contact" href="contact">
                                <img src="<?php echo e(asset ('img/contact.png')); ?>" alt="">
                            </a>
                        </div>

                        <div
                            style="width: 50%; height: 1px; margin: 7% 0px; background-color: rgb(0, 0, 0); text-align: center;">
                        </div>

                        <img src="<?php echo e(asset('img/s-l400.jpeg')); ?>" width="70%" alt="">
                        <div
                            style="width: 50%; height: 1px; margin: 10% 0px; background-color: rgb(0, 0, 0); text-align: center;">
                        </div>
                        <img src="<?php echo e(asset('img/247.png')); ?>" width="30%" alt="">
                        <div
                            style="width: 50%; height: 1px; margin: 10% 0px; background-color: rgb(0, 0, 0); text-align: center;">
                        </div>
                        <p style="font-family: robotsan;">login/register</p>
                    </div>


                    <div class="left_form_wrapper">
                    <form style="margin-top: 4%;width:80%;">

                        <div>
                            <label style="font-size: 14px;  font-family: sans-serif;  font-weight: 400;" for="username">
                                Username or Email Address
                            </label>
                            <input type="text" name="Username"
                                style="width: 95%; height: 40px; border: none; outline: 1px solid black; margin-bottom: 3%;">
                        </div>

                        <div>
                            <label for="password" style="font-size: 14px; font-family: sans-serif; font-weight: 400;">
                                Password
                            </label>
                            <input type="password" name="password"
                                style="width: 95%; height: 40px; border: none; outline: 1px solid black;margin-bottom: 3%;">
                        </div>

                        <div>
                            <input type="checkbox" name="Remember" id="Remember"> <span
                                style="font-size: 12px;">Remember Me</span>
                        </div>

                        <div>
                            <button type="submit"
                                style="border: none; background: #0042AF; margin-top: 2%; text-transform: uppercase; font-size: 12px; font-weight: 600; padding: 8px 12px; width: 25%; color: white;">Log
                                in</button>
                        </div>

                        <div>
                            <a href="#" id="lost" style="color:rgba(0 0 0 /.7); font-size: 12px;">Lost your
                                password?<a><a href="" style="display: inline;">|Register</a>
                        </div>
                        </form>
                    </div>

                    <div
                        style="width: 50%; height: 1px; margin: 10% 0px; background-color: rgb(0, 0, 0); text-align: center;">
                    </div>

                    <a href="index.html" style="width: 90%;">
                        <img style="" src="<?php echo e(asset('img/cropped-EDLifecare-logo.png')); ?>" width="80%" alt="">
                    </a>
                </div>

            </div>

            <div id="rightsideproduct">

                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
              
                    <div class="productcard">
                        <div class="productimg">
                            <img src="<?php echo e(asset ($product->prd_image)); ?>" alt="">
                            <div class="sale">SALE!</div>
                        </div>

                        <div class="discription">
                            
                                <p><?php echo e($product->prd_dis); ?></p>
                        </div>

                        <div class="productname"><?php echo e($product->prd_name); ?></div>

                        <div class="price"
                            style="margin-top: 10%; color: #57BF6D; font-size: 18px; font-family: robotsan; ">
                            <p>$<?php echo e($product->prd_min_price); ?> - $<?php echo e($product->prd_max_price); ?></p>
                        </div>


                      

                       

                        <a href="/singleproduct?id=<?php echo e($product->id); ?>" id="buybutton">Select options</a>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                


                



                

                

                


                

                

                

                

            </div>
        </div>

    </div>



</section>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\MSI\Documents\github\laravel\my_first_app\A_WEBSITE\resources\views/home.blade.php ENDPATH**/ ?>