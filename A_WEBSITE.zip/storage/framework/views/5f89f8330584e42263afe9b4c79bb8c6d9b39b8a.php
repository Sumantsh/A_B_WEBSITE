<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section id="section" x-data="{
    cartData: [],
    showCart: false,
    cartItems: 0,
    getCartData() {
        fetch('/get-cart-data')
            .then((response) => response.json())
            .then((json) => {
                this.cartData = json.data;
                this.cartItems = this.cartData.length;
            });
    }
}" x-init="getCartData()">

    <div id="productdevider">

        <div class="productimg">
            <img src="<?php echo e(asset ($product->prd_image)); ?>" alt="">
            <div id="sale2" class="sale">SALE!</div>
            <i class="fa-solid fa-magnifying-glass" id="search"></i>
        </div>

        <div id="productinfo">
            <div class="productname">
                <h2 style="font-size: 24px; font-weight: 600; font-family: 'Poppins', sans-serif; letter-spacing: 1px; color:#333;">
                    <?php echo e($product->prd_name); ?></h2>
                <i class="fa-solid fa-chevron-right"></i>
            </div>

            <div class="price">
                <p style="font-size: 30px; font-family: 'Poppins', sans-serif; font-weight: 600;  margin: 4% 0px; color:#57bf6d; ">
                    <span id="productpricein">$ <?php echo e($product->prd_min_price); ?></span>  <span id="productpricein">– $  <?php echo e($product->prd_max_price); ?></span></p>
                <p style="font-size: 14px ;  font-family: 'Poppins', sans-serif: #5f5f5f; margin-bottom: 4%;"><?php echo e($product->prd_about); ?></p>
            </div>

            <div id="option">

                <?php
                    $pills = explode("*", $product->prd_qty);
                    $mg = explode("*", $product->prd_mg);
                ?>
        
                <div class="quantity">
                    <p>Quantity</p>
                    <select name="quantity" id="pillsquantity">
                        <option value="0">Choose an option</option>
                        <?php $__currentLoopData = $pills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item); ?>"><?php echo e($item); ?>pills</option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="mg">
                    <p>MG</p>
                    <select name="mg" id="pillsmg">
                        <option value="0">Choose an option</option>
                        <?php $__currentLoopData = $pills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item); ?>"><?php echo e($item); ?>mg</option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div id="addcart">
                <div class="addition">
                    <button id="minus" value="-1">-</button>
                    <div id="showvalue" step="1" inputmode="numeric">1</div>
                    <button id="plus" value="1" step="1">+</button>
                </div>

                <div class="cart">
                    <button style="cursor: pointer" type="button" name="cart_btn" data-productID="<?php echo e($product->id); ?>"  id="addtocart" @click="function() {
                        getCartData(); 
                        showCart = true;
                    }">ADD TO CART</button>
                </div>
            </div>


        </div>

        <div class="blank"></div>

    </div>

    <!-- cartwindow -->

    <div id="cartwindow" x-show="showCart">

        <div class="innerwindow">
            <div class="topwrapper">
                <div class="icon" style="position: relative;"><span><img src="<?php echo e(asset ('img/icon/bag.svg')); ?>" width="30px"
                            style="position: relative;" alt=""> <span
                            style="position: absolute; right: 10%; top: 27%; ">1</span> </span></div>

                <div class="heading" style=" width: 55%;  padding: 0px 10px;">
                    <p>Your Cart</p>
                </div>

                <div class="cross" style="width:auto; cursor: pointer; ">
                    <i class="fa-solid fa-xmark"></i>
                </div>

            </div>

            <template x-for="data in cartData">
                <div id="productvalues">
                    <div class="productimg">
                        <img x-bind:src="data.prd_image"  alt="">
                    </div>
    
                    <div class="numberofitems">
                        <p style="font-family: 'Poppins', sans-serif; "><span x-text="data.prd_name"></span> - <span id="mumberofpills" x-text="data.pills"></span><span> pills,</span><br>
                        <span id="pillsmg" x-text="data.mg"></span><span> mg</span> </p>
                        <p><span id="itemsvalues" x-text="data.qty"></span> <span>X</span> <span>$ <span id="productprice">59.80</span>
                        <span>=</span> <span>$</span> <span id="totalprice">59.80</span> </span></p>
                    </div>
    
                    <div class="delete" @click="function() {
                        cartItems = remove($event, data.UID);
                    }">
                        <i class="fa-regular fa-trash-can"></i>
                    </div>
                </div>
            </template>
            

            <div id="checkout" style="background: ">

                <div class="subtotal"> Subtotal: <span style="margin-left: 0%; color: #57BF6D;">$</span> <span style="margin-left: -5px; color: #57BF6D;">86.88</span> 
                </div>
                
            
            <div class="buttonwrapper">
                
                <div class="checkout" @click="payment($event, cartData)">
                    <a href="">CHECKOUT</a>
                </div>
                
                <div class="viewcart">
                    <a href="">VIEW CART</a>
                </div>

                <div class="continushoping">
                    <a href="">CONTINUE SHOPPING</a>
                </div>
                
            </div>
            </div>
        </div>
    </div>

    <div id="carticon2" @click="showCart = !showCart">
        <img src="<?php echo e(asset ('img/icon/bagicon.svg')); ?>" class="bagicon" alt="">
        <div
            style="position: absolute; background: black; border-radius: 50%; width:40px;height:40px; color: white; text-align: center; top: -12px; left: -7px; box-shadow: 2px 2px 4px rgba(0, 0, 0,.4) ; display:flex; justify-content:center; align-items:center; ">
            <span x-text="cartItems"></span></div>
    </div>


    <div id="productdis">

        <div class="leftoption">
            <p id="discription">DESCRIPTION </p>
            <p id="additional">ADDITIONAL INFORMATION</p>
            <p id="review">REVIEWS</p>
        </div>

        <div class="rightdis">
            


            <?php
                print_r($product->prd_details);
            ?>


        </div>

        <div id="blank2"></div>

    </div>

</section>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\MSI\Desktop\laravel\my_first_app\A_WEBSITE\resources\views/singleproduct.blade.php ENDPATH**/ ?>