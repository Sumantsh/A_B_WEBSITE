<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


  


    <section id="samplesection" >


      <h2 style="padding:10px; color: #0042AF; font-family: open, sans-serif; font-size: 40px; margin-left:5%; border-bottom: 1px solid rgba(0 0 0 /.4);">FREE SAMPLES</h2>

      <div id="rightsideproduct2" style="" >
        <div class="row row1">
        
          <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div id="productcard" >

            <div class="productimg_on_sample" style="">
              <img src="<?php echo e(asset( $product['prd_image'] )); ?>" width="100%" alt="">
            </div>

            <div class="discription" style="" >
              <p> <?php echo e($product['prd_dis']); ?></p>
            </div>

            <div class="productname" style="">
              <?php echo e($product['prd_name']); ?></div>

            <div class="price" style=" ">
              <p>$<?php echo e($product['prd_min_price']); ?></p>
            </div>



            <div class="btn_wrapper">
              <button data-productID="<?php echo e($product->id); ?>" data-productPrice="<?php echo e($product['prd_min_price']); ?>"  id="addtocartsample" wire:click="toggleCart" >Add to Cart</button>
            </div>

            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </section>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('cart', [])->html();
} elseif ($_instance->childHasBeenRendered('L78XCLa')) {
    $componentId = $_instance->getRenderedChildComponentId('L78XCLa');
    $componentTag = $_instance->getRenderedChildComponentTagName('L78XCLa');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('L78XCLa');
} else {
    $response = \Livewire\Livewire::mount('cart', []);
    $html = $response->html();
    $_instance->logRenderedChild('L78XCLa', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\MSI\Documents\github\laravel\my_first_app\A_WEBSITE\resources\views/sample.blade.php ENDPATH**/ ?>