<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section id="section">

    <div id="productdevider">
        <div class="productimg">
            <img src="<?php echo e(asset ($product->prd_image)); ?>" alt="">
            <div id="sale2" class="sale">SALE!</div>
            <i class="fa-solid fa-magnifying-glass" id="search"></i>
        </div>

        <div id="productinfo" data-perpillprice="<?php echo e($product->price_per_pill); ?>">
            <div class="productname">
                <h2 style="font-size: 24px; font-weight: 600; font-family: 'Poppins', sans-serif; letter-spacing: 1px; color:#333;">
                    <?php echo e($product->prd_name); ?></h2>
                <i class="fa-solid fa-chevron-right"></i>
            </div>

            <div class="price">
                <p style="font-size: 30px; font-family: 'Poppins', sans-serif; font-weight: 600;  margin: 4% 0px; color:#57bf6d; ">
                    <span>$ <span id="productpricemin"><?php echo e($product->prd_min_price); ?></span></span>  <span id="productpricemax">– $  <?php echo e($product->prd_max_price); ?></span></p>
                <p style="font-size: 14px ;  font-family: 'Poppins', sans-serif: #5f5f5f; margin-bottom: 4%;"><?php echo e($product->prd_about); ?></p>
            </div>

            <div id="option">

                <?php
                    $pills = explode("*", $product->prd_qty);
                    $mg = explode("*", $product->prd_mg);
                ?>
        
                <div class="quantity">
                    <p>Quantity</p>
                    <select name="quantity" id="pillsquantity">
                        <option value="0">Choose an option</option>
                        <?php $__currentLoopData = $pills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item); ?>"><?php echo e($item); ?>pills</option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="mg">
                    <p>MG</p>
                    <select name="mg" id="pillsmg">
                        <option value="0">Choose an option</option>
                        <?php $__currentLoopData = $mg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item); ?>"><?php echo e($item); ?>mg</option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

        <div class="amount_show">$<span class="blank"></span></div>


            <div id="addcart">
                <div class="addition">
                    <button id="minus" value="-1">-</button>
                    <div id="showvalue" step="1" inputmode="numeric">1</div>
                    <button id="plus" value="1" step="1">+</button>
                </div>

                <div class="cart">
                    <button style="cursor: pointer" type="button" name="cart_btn" data-productID="<?php echo e($product->id); ?>"  id="addtocart" wire:click="toggleCart">ADD TO CART</button>
                </div>
            </div>


        </div>


    </div>

    <!-- cartwindow -->
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('cart', [])->html();
} elseif ($_instance->childHasBeenRendered('TucXLX6')) {
    $componentId = $_instance->getRenderedChildComponentId('TucXLX6');
    $componentTag = $_instance->getRenderedChildComponentTagName('TucXLX6');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('TucXLX6');
} else {
    $response = \Livewire\Livewire::mount('cart', []);
    $html = $response->html();
    $_instance->logRenderedChild('TucXLX6', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <div id="productdis">

        <div class="leftoption">
            <p id="discription">DESCRIPTION </p>
            <p id="additional">ADDITIONAL INFORMATION</p>
            <p id="review">REVIEWS</p>
        </div>

        <div class="rightdis">
            <div>
            <?php
                print_r($product->prd_details);
            ?> 
                <center><img src="<?php echo e(asset('img/pack.png')); ?>"></center>
            </div>

        </div>

        <div id="blank2"></div>

    </div>

</section>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\MSI\Documents\github\laravel\my_first_app\A_WEBSITE\resources\views/singleproduct.blade.php ENDPATH**/ ?>