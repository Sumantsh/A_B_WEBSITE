<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section id="samplesection" style="margin:5% 0px;  width: 100%; display: flex; flex-direction: column; justify-content: flex-start; ">


      <h2 style="padding:10px; color: #0042AF; font-family: open, sans-serif; font-size: 40px; margin-left:5%; border-bottom: 1px solid rgba(0 0 0 /.4);">FREE SAMPLES</h2>

      <div id="rightsideproduct" style="width: 80%; margin-left: 5%; display: flex; flex-direction: column; flex-wrap: wrap; justify-content: space-around; padding: 5px 7px; border-radius: 4px;" >
         
        <div class="row row1">

          <div id="productcard" >

           <div class="productimg" style="width:100%; display: grid; place-items: center; position: relative; " >
             <img src="/static/img/products/Viagra.jpg" width="60%" alt="">
             <div class="sale" style="position: absolute; font-family: sans-serif; font-size: 12px; color: white; font-weight: 600; width: 20%; background: #65CF9F; padding: 5px; text-align: center; top: 10%; left: 15%; border-radius: 8px;">SALE!</div>
           </div>

           <div class="discription" style="width:100%; text-align: center; line-height: 1; color: rgba(0 0 0 /.4); margin-top: 8%; font-size: 12px; font-family: sans-serif; font-style: italic; " >
             <p> <span> Brand Viagra,</span> <span>Viagra,</span> <span>Viagra – professional,</span> <span>Viagra Plus</span></p>
           </div>

           <div class="productname" style="margin-top: 2%; font-size: 14px; font-weight: 500;  font-family: open, sans-serif;">Viagra</div>

           <div class="price" style="margin-top: 10%; color: #57BF6D; font-size: 18px; font-family: robotsan; ">
             <p>$43.44 - $343.70</p>
           </div>

           <a href="Productview" id="buybutton" >Select options</a>



          </div>


          <div id="productcard">
           <div class="productimg" style="width:100%; display: grid; place-items: center; position: relative; " >
             <img src="/static/img/products/Viagra-–-professional.jpg" width="60%" alt="">
             <div class="sale" style="position: absolute; font-family: sans-serif; font-size: 12px; color: white; font-weight: 600; width: 20%; background: #65CF9F; padding: 5px; text-align: center; top: 10%; left: 15%; border-radius: 8px;">SALE!</div>
           </div>

           <div class="discription" style="width:100%; text-align: center; line-height: 1; color: rgba(0 0 0 /.4); margin-top: 8%; font-size: 12px; font-family: sans-serif; font-style: italic; " >
             <p> <span> Brand Viagra,</span> <span>Viagra,</span> <span>Viagra – professional,</span> <span>Viagra Plus</span></p>
           </div>

           <div class="productname" style="margin-top: 2%; font-size: 14px; font-weight: 500;  font-family: open, sans-serif;">Viagra – professional </div>

           <div class="price" style="margin-top: 10%; color: #57BF6D; font-size: 18px; font-family: robotsan; ">
             <p>$52.6 - $162.40</p>
           </div>

           <a href="Productview" id="buybutton" >  Select options</a>
          </div>
          
          <div id="productcard">

           <div class="productimg" style="width:100%; display: grid; place-items: center; position: relative; " >
           <img src="/static/img/products/Cialis.jpg" width="60%" alt="">
           <div class="sale" style="position: absolute; font-family: sans-serif; font-size: 12px; color: white; font-weight: 600; width: 20%; background: #65CF9F; padding: 5px; text-align: center; top: 10%; left: 15%; border-radius: 8px;">SALE!</div>
         </div>

         <div class="discription" style="width:100%; text-align: center; line-height: 1; color: rgba(0 0 0 /.4); margin-top: 8%; font-size: 12px; font-family: sans-serif; font-style: italic; " >
           <p> <span> Brand Viagra,</span> <span>Viagra,</span> <span>Viagra – professional,</span> <span>Viagra Plus</span></p>
         </div>

         <div class="productname" style="margin-top: 2%; font-size: 14px; font-weight: 500;  font-family: open, sans-serif;">Cialis</div>

         <div class="price" style="margin-top: 10%; color: #57BF6D; font-size: 18px; font-family: robotsan; ">
           <p>$49.50 - $343.70</p>
         </div>

         <a href="Productview" id="buybutton">Select options</a>
       
       </div>

        </div>

    </section>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MSI\Desktop\laravel\my_first_app\A_B_WEBSITE\resources\views/sample.blade.php ENDPATH**/ ?>