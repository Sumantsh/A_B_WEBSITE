<div id="footer">

    <div id="flogo">
      <a href="index.html">
        <img src="<?php echo e(asset ('img/cropped-EDLifecare-logo.png')); ?>" class="flogo" alt="logo">
      </a>
    </div>

    <div id="fnav">

      <div class="navfooter">

        <a href="">About us</a>
        <a href="">F&Q</a>
        <a href="">Free Samples</a>
        <a href="">Policies</a>
        <a href="">Shipping</a>

      </div>

      <div class="companyinfo">
        <p >ED LIFE CARE PHARMACY Ltd. is Licensed online pharmacy. Internationally license number 198 – 10814856</p>
        <p id="issued">issued July 03 2021</p>
      </div>

    </div>

    

    </div>

    <div style="width: 100%; height: 1px; margin: 2% 0px; background-color: rgba(0, 0, 0,.4); text-align: right;"></div>
    <div id="copyright">
      <p>© 2001 – 2022 EdlifeCare.com. All rights reserved</p>
    </div>
  </footer>

  
<script src=" https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.js"></script>
<script src="<?php echo e(asset('js/script.js')); ?>"></script>
<script src="<?php echo e(asset('js/swiperscript.js')); ?>"></script>
<script src="<?php echo e(asset('js/cartwindow.js')); ?>"></script>

</body>
</html><?php /**PATH C:\Users\MSI\Desktop\laravel\my_first_app\A_WEBSITE\resources\views/footer.blade.php ENDPATH**/ ?>